<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "newdbb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$title = $_POST['title'];
$author = $_POST['author'];
$year = $_POST['year'];

$sql = "INSERT INTO books (title, author, year_published) VALUES ('$title', '$author', $year)";
$result = $conn->query($sql);

$conn->close();

header("Location: index.php");
exit();
?>