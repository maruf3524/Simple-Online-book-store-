<!-- process_book.php -->

<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli('localhost', 'root', '', 'newdb');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $title = $_POST['title'];
    $author = $_POST['author'];
    $year_published = $_POST['year_published'];
    $username = $_SESSION['username'];
    $current_time = date("Y-m-d H:i:s");; // Get current date and time

    // Insert book record into the record_book table
    

    $sql = "INSERT INTO book_record (title, author, year_published, username, date_added) 
            VALUES ('$title', '$author', '$year_published', '$username', '$current_time')";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
