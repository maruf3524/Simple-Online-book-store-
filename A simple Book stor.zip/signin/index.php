<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Book</title>
    
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.min.js"></script>
    <link rel="stylesheet" href="style.css">
    <!-- display_books.php - Head section -->


    <!-- ... other meta tags ... -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
    <link rel="stylesheet" href="style.css">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-repeat" viewBox="0 0 16 16">

 
</svg>

</head>
<body>

<div class="container mt-5">
    <h1>Add New Book</h1>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addBookModal"><i class="fas fa-plus"></i>
        Add Book
    </button>
    <a href="login.php" class="btn btn-danger">
    <i class="fas fa-minus"></i> Logut
</a>

</div>

<!-- Modal -->
<div class="modal fade" id="addBookModal" tabindex="-1" aria-labelledby="addBookModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBookModalLabel">Add New Book</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Form for adding a new book -->
                <form action="process_book.php" method="post"> <!-- replace add_book.php with your server-side script -->
                    <div class="mb-3">
                        <label for="bookTitle" class="form-label">Title</label>
                        <input type="text" class="form-control" id="bookTitle" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="author" class="form-label">Author</label>
                        <input type="text" class="form-control" id="author" name="author" required>
                    </div>
                    <div class="mb-3">
                        <label for="publishedYear" class="form-label">Date Of Published</label>
                        <input type="date" class="form-control" id="publishedYear" name="year_published" required>
                    </div>
                    
                    <button type="submit"  class="btn btn-primary"><i class="fas fa-plus"></i>Add Book</button>
                </form>
            </div>
        </div>
    </div>
</div>
<br><br><br>
<table id="bookTable" class="table table-striped table-bordered" style="width:100%">
    <thead>
        <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Date Of Publishe</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $conn = new mysqli('localhost', 'root', '', 'newdb');

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $result = $conn->query("SELECT * FROM book_record");
       
        session_start();
         $username = $_SESSION["username"];


        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                      <td>{$row['title']}</td>
                      <td>{$row['author']}</td>
                      <td>{$row['year_published']}</td>
                      <td>
                          <a href='edit_book.php?id={$row['id']}' class='btn btn-warning btn-sm'><i class='bi bi-arrow-repeat'><i class='fas fa-edit'></i>Edit</a>
                          <a href='delete_book.php?id={$row['id']}' class='btn btn-danger btn-sm' onclick='return confirm(\"Are you sure you want to delete this book?\")'><i class='fas fa-minus'></i>Delete</a>
                      </td>
                  </tr>";
        }

        $conn->close();
        ?>
    </tbody>
</table>
</div>

<!-- Bootstrap JS (Popper.js and Bootstrap JS) -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.min.js"></script>

<script>
    $(document).ready(function () {
        $('#bookTable').DataTable();
    });
</script>


</body>
</html>
