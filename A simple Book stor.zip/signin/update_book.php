<!-- process_edit_book.php -->

<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $conn = new mysqli('localhost', 'root', '', 'newdb');

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $id = $_POST['id'];
    $title = $_POST['title'];
    $author = $_POST['author'];
    $year_published = $_POST['year_published'];
    $name_of_updater = $_SESSION['username'];

    // Capture the current time
    $current_time = date("Y-m-d H:i:s");

    // Update book record in the record_book table
    $sql = "UPDATE book_record 
            SET title = '$title', author = '$author', year_published = '$year_published', 
            name_of_updater = '$name_of_updater', time_updated = '$current_time'
            WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        
       
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $conn->close();
}
?>
