<!-- display_books.php -->

<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Display book list or any other content for logged-in users
// ...

// Add a link to logout (logout.php)
echo '<a href="index.php" class="btn btn-primary">add book list</a>';
?>
